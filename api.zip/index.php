<?php
echo "hi! world..."

?>